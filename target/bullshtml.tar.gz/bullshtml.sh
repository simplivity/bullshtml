#/usr/bin/sh
jarpath=`dirname $0`
java -jar ${jarpath}/bullshtml.jar $*